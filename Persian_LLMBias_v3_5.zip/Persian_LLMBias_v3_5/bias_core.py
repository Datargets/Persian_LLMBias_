"""StereoSet-adapted Persian evaluation v3.5: corrected source labels and safe Colab scoring.
Scores are full-sentence causal log-likelihood, NOT PLL; human validity pending.
"""
from __future__ import annotations
import hashlib, json, math, os, platform, warnings
from pathlib import Path
from datetime import datetime, timezone
import numpy as np
import pandas as pd

LABEL_FROM_GOLD={0:'anti-stereotype',1:'stereotype',2:'unrelated'}
LABELS=('stereotype','anti-stereotype','unrelated')
LANG_COL={'English':'English Sentence','Persian':'Persian Sentence'}
SCHEMA=['bias_type','context','gold_label','English Sentence','Persian Sentence']
METHOD_VERSION='v3.5.expert_reviewed.full_sentence_causal_utf8_bpb.official_gold_labels'

def sha(s): return hashlib.sha256(str(s).encode('utf8')).hexdigest()

def clean_dataset(df):
    """Derive label from numeric official StereoSet gold_label, NEVER from legacy label_name.
    item_id is LABEL-INDEPENDENT to keep score/text join stable after label review.
    """
    d=df.copy().drop(columns=[c for c in df.columns if c.startswith('Unnamed:')],errors='ignore')
    if 'full_sentence' in d and 'English Sentence' not in d: d=d.rename(columns={'full_sentence':'English Sentence'})
    missing=set(SCHEMA)-set(d.columns)
    if missing:raise ValueError(f'Missing original dataset fields: {sorted(missing)}')
    if d[SCHEMA].isna().any().any():raise ValueError('Nulls in source data')
    d['gold_label']=pd.to_numeric(d['gold_label'],errors='raise').astype(int)
    if not set(d.gold_label).issubset(LABEL_FROM_GOLD):raise ValueError('Unrecognized StereoSet gold_label')
    expected=d.gold_label.map(LABEL_FROM_GOLD)
    if 'label_name' in d and 'legacy_label_name' not in d:
        d['legacy_label_name']=d['label_name'].astype(str)
    d['source_label_name']=expected  # Official unchanged reference even when approved human labels override
    if 'validated_label' in d:
        if 'review_status' not in d or not d.review_status.astype(str).eq('APPROVED').all():
            raise ValueError('All rows require APPROVED human review to use validated_label')
        new_label=d.validated_label.astype(str).str.strip().str.lower()
        if not set(new_label).issubset(LABELS):raise ValueError('Invalid approved human label')
        d['label_name']=new_label
    else:
        d['label_name']=expected
    for c in ['context','English Sentence','Persian Sentence','bias_type']:
        if d[c].astype(str).str.strip().eq('').any():raise ValueError('Empty '+c)
    d['prompt_id']=[sha(cat+'\0'+ctx)[:16] for cat,ctx in zip(d.bias_type.astype(str),d.context.astype(str))]
    d['item_id']=[p+':'+sha(en)[:16] for p,en in zip(d.prompt_id,d['English Sentence'])]
    if d.item_id.duplicated().any():raise ValueError('Repeated item identity: check identical English completions')
    sizes=d.groupby('prompt_id').size()
    if not sizes.eq(3).all():raise ValueError('Expected exactly three completions per source prompt')
    cnt=d.groupby(['prompt_id','label_name']).size().unstack(fill_value=0).reindex(columns=list(LABELS),fill_value=0)
    if not cnt.eq(1).all().all():raise ValueError('Missing/duplicate official completion labels in a prompt')
    if d.groupby('prompt_id').bias_type.nunique().gt(1).any():raise ValueError('Prompt category mismatch')
    return d.reset_index(drop=True)

def dataset_digest(df):
    d=clean_dataset(df).sort_values('item_id')
    cols=['item_id','prompt_id','gold_label','label_name','English Sentence','Persian Sentence']
    return sha(d[cols].to_csv(index=False,lineterminator='\n'))

def dataset_audit(df):
    d=clean_dataset(df)
    legacy=int((d.legacy_label_name.str.strip().str.lower()!=d.source_label_name).sum()) if 'legacy_label_name' in d else None
    return dict(rows=int(len(d)),prompts=int(d.prompt_id.nunique()),language_items=int(2*len(d)),
        labels=d.label_name.value_counts().to_dict(),categories=d.groupby('bias_type').prompt_id.nunique().to_dict(),
        legacy_label_mismatches=legacy,approved_human_labels=int('validated_label' in d.columns),intrasentence_blank_contexts=int(d.context.str.contains('BLANK',regex=False).sum()),
        duplicate_persian_rows_within_prompt=int(d.duplicated(['prompt_id','Persian Sentence'],keep=False).sum()),
        prompts_with_collapsed_persian_options=int(d.loc[d.duplicated(['prompt_id','Persian Sentence'],keep=False),'prompt_id'].nunique()),
        dataset_sha256=dataset_digest(d),translation_and_cultural_validity='ONE_LINGUIST_TRANSLATION_AUDIT; NO_CULTURAL_REANNOTATION_OR_IAA',
        source_config_confirmation='PENDING_CANONICAL_ID_MATCH',
        caveat='The historical notebook names intersentence despite BLANK contexts. Source configuration unverified until upstream ID/content audit.')



def verify_source_against_hf(df,allow_network=True):
    """Optional provenance audit: tries BOTH configs, no silent relabeling or fabricated IDs."""
    if not allow_network:return {'status':'SKIPPED_OFFLINE'}
    from datasets import load_dataset
    d=clean_dataset(df)
    target=set(zip(d.context.astype(str),d['English Sentence'].astype(str),d.gold_label.astype(int)))
    reports={}
    for cfg in ['intrasentence','intersentence']:
        try:
            raw=load_dataset('McGill-NLP/stereoset',cfg,split='validation')
            canon=set()
            for record in raw:
                s=record['sentences']
                for text,label in zip(s['sentence'],s['gold_label']):
                    canon.add((str(record['context']),str(text),int(label)))
            overlap=len(target & canon)
            reports[cfg]={'exact_item_matches':overlap,'of':len(target),'coverage':overlap/len(target)}
        except Exception as e: reports[cfg]={'error':str(e)[:500]}
    return {'status':'COMPLETE' if any(v.get('exact_item_matches')==len(target) for v in reports.values()) else 'UNVERIFIED',
            'configs':reports,'note':'Exact context+English sentence+gold label; no fuzzy matching. Human translation audit still required.'}

def load_causal_model(model_id, *, token=None, revision=None, quantize_4bit=True):
    """HF model at resolved commit. Colab GPU. No generation and no stochastic decoding."""
    import torch
    from huggingface_hub import HfApi
    from transformers import AutoTokenizer,AutoModelForCausalLM,BitsAndBytesConfig
    if not torch.cuda.is_available():raise RuntimeError('Select GPU in Colab Runtime settings')
    info=HfApi(token=token).model_info(model_id,revision=revision or 'main')
    commit=info.sha
    tok=AutoTokenizer.from_pretrained(model_id,token=token,revision=commit,trust_remote_code=False)
    if tok.bos_token_id is None:raise ValueError('Tokenizer needs BOS token; explicit scoring convention required')
    # BF16 is only native on Ampere-or-newer NVIDIA GPUs (CC >= 8.0).
    # Tesla T4 (7.5) must score in FP16 rather than emulated BF16.
    compute_capability = torch.cuda.get_device_capability(0)
    native_bf16 = compute_capability[0] >= 8 and torch.cuda.is_bf16_supported()
    dtype = torch.bfloat16 if native_bf16 else torch.float16
    kw=dict(token=token,revision=commit,device_map='auto',torch_dtype=dtype,trust_remote_code=False)
    if quantize_4bit:
        kw['quantization_config']=BitsAndBytesConfig(load_in_4bit=True,bnb_4bit_quant_type='nf4',
              bnb_4bit_compute_dtype=dtype,bnb_4bit_use_double_quant=True)
    model=AutoModelForCausalLM.from_pretrained(model_id,**kw)
    model.eval()
    return model,tok,commit

def score_sentence(model,tokenizer,text):
    """Full-sentence likelihood with BOS + all content tokens; PPL token-level diagnostic only."""
    import torch
    if not isinstance(text,str) or not text:raise ValueError('Empty or non-string sentence')
    ids=tokenizer(text,add_special_tokens=False)['input_ids']
    if not ids:raise ValueError('Empty tokenization')
    tokens=[tokenizer.bos_token_id]+ids
    limit=getattr(model.config,'max_position_embeddings',None)
    if limit and len(tokens)>limit:raise ValueError('Sequence exceeds model context, do not truncate')
    x=torch.tensor([tokens],device=model.get_input_embeddings().weight.device,dtype=torch.long)
    with torch.inference_mode():
        logits=model(input_ids=x,use_cache=False).logits[:,:-1,:].float()
        selected=torch.nn.functional.log_softmax(logits,dim=-1).gather(-1,x[:,1:].unsqueeze(-1)).squeeze(-1)
        ll=float(selected.sum().item())
    nt=len(ids);nb=len(text.encode('utf8'));nc=len(text); nll=-ll;log_ppl=nll/nt
    return dict(log_likelihood=ll,n_content_tokens=nt,n_bytes=nb,n_chars=nc,
        bpb=nll/(math.log(2)*nb),bpc=nll/(math.log(2)*nc),nll_per_token=log_ppl,
        log_ppl_token=log_ppl,ppl_token=float(math.exp(log_ppl)) if log_ppl<700 else math.inf,
        cpt=nc/nt,bytes_per_token=nb/nt)

def score_metadata(model,tokenizer,model_id,commit,quantized,df):
    import torch,transformers
    digest=dataset_digest(df)
    provenance={}
    if 'source_config' in df.columns and 'canonical_dataset_commit_sha' in df.columns:
        cfg=df.source_config.astype(str).unique().tolist()
        sha_values=df.canonical_dataset_commit_sha.astype(str).unique().tolist()
        if len(cfg)!=1 or len(sha_values)!=1:raise ValueError('Inconsistent canonical source provenance in dataset')
        provenance=dict(source_repo='McGill-NLP/stereoset',source_config=cfg[0],source_commit=sha_values[0],source_split='validation')
    else:
        raise ValueError('Source provenance required for v3.5: use the validated expert-reviewed dataset and manifest')
    config=dict(method=METHOD_VERSION,model_id=model_id,resolved_commit=commit,dataset_sha256=digest,**provenance,
          quantization_4bit_nf4=bool(quantized),tokenizer_class=tokenizer.__class__.__name__,
          dtype=str(getattr(model,'dtype','unknown')),
          nf4_compute_dtype=str(getattr(getattr(model,'quantization_config',None),'bnb_4bit_compute_dtype', 'not_reported')),
          gpu_compute_capability=list(torch.cuda.get_device_capability(0)))
    rid=sha(json.dumps(config,sort_keys=True))
    return dict(**config,run_id=rid,model_architecture=str(getattr(model.config,'model_type','unknown')),
        vocab_size=len(tokenizer),torch_version=torch.__version__,transformers_version=transformers.__version__,
        python=platform.python_version(),gpu=torch.cuda.get_device_name(0),
        timestamp_utc=datetime.now(timezone.utc).isoformat(),seed=42,
        scoring_scope='Unconditional full sentence with BOS, including ALL text tokens; not completion-only and not StereoSet leaderboard score.',
        translation_validity='ONE_LINGUIST_TRANSLATION_AUDIT; FINAL_AI_ASSISTED_RESOLUTIONS_NOT_REREVIEWED')

def _atomic_csv(df,path):
    path=Path(path);path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_suffix('.csv.tmp');df.to_csv(tmp,index=False);os.replace(tmp,path)

def score_frame(df,model,tokenizer,model_label,*,output_file,checkpoint_every=24,max_prompts=None,run_id=None):
    from tqdm.auto import tqdm
    d=clean_dataset(df)
    if max_prompts is not None:
        ps=d.prompt_id.drop_duplicates().iloc[:max_prompts]; d=d[d.prompt_id.isin(ps)]
    out=Path(output_file)
    expected={(x,lang) for x in d.item_id for lang in LANG_COL}
    existing=pd.read_csv(out) if out.exists() else pd.DataFrame()
    if len(existing):
        if not existing.run_id.eq(run_id).all():raise ValueError('Checkpoint run_id mismatch. Do not mix model/data configurations.')
        if not existing.model.eq(model_label).all():raise ValueError('Checkpoint model label mismatch')
        if existing.duplicated(['item_id','language']).any():raise ValueError('Duplicate checkpoint keys')
    cache={(r['item_id'],r['language']):r for r in existing.to_dict('records')}
    for n,(_,row) in enumerate(tqdm(d.iterrows(),total=len(d),desc=model_label),start=1):
        for language,col in LANG_COL.items():
            key=(row.item_id,language)
            if key in cache:continue
            s=score_sentence(model,tokenizer,str(row[col]))
            s.update(item_id=row.item_id,prompt_id=row.prompt_id,model=model_label,run_id=run_id,
                     language=language,bias_type=row.bias_type,label_name=row.label_name,
                     gold_label=int(row.gold_label),text_sha256=sha(row[col]))
            cache[key]=s
        if n%checkpoint_every==0:_atomic_csv(pd.DataFrame(cache.values()),out)
    scored=pd.DataFrame(cache.values())
    if set(zip(scored.item_id,scored.language))!=expected:raise ValueError('Incomplete/misaligned scoring')
    by_id=d.set_index('item_id')
    for row in scored.itertuples(index=False):
        source=by_id.loc[row.item_id]
        if sha(source[LANG_COL[row.language]])!=row.text_sha256:raise ValueError('Stale text checkpoint')
        if row.label_name!=source.label_name or int(row.gold_label)!=int(source.gold_label):raise ValueError('Label inconsistency')
    _atomic_csv(scored,out)
    return scored

def verify_scores(scores,df,model_labels=('LLaMA','PersianLLaMA')):
    d=clean_dataset(df)
    needed=['item_id','prompt_id','model','language','bias_type','label_name','gold_label',
           'log_likelihood','bpb','ppl_token','log_ppl_token','n_content_tokens','n_bytes','text_sha256','run_id']
    missing=set(needed)-set(scores.columns)
    if missing:raise ValueError('Missing score columns '+str(missing))
    if len(scores)!=len(d)*len(LANG_COL)*len(model_labels):raise ValueError('Score file incomplete or contains extra rows')
    if scores.duplicated(['item_id','language','model']).any():raise ValueError('Duplicate scores')
    if not np.isfinite(scores[['bpb','log_likelihood','log_ppl_token']]).all().all():raise ValueError('Nonfinite scores')
    look=d.set_index('item_id')
    if set(scores.item_id)!=set(look.index):raise ValueError('Score vs dataset item mismatch')
    if set(scores.model)!=set(model_labels):raise ValueError('Unexpected model labels')
    for (model,language),part in scores.groupby(['model','language']):
        if len(part)!=len(d):raise ValueError('Incomplete '+model+'/'+language)
        if part.run_id.nunique()!=1:raise ValueError('Mixed runs for '+model)
        target=part.item_id.map(look['label_name'])
        if not part.label_name.reset_index(drop=True).equals(target.reset_index(drop=True)):
            raise ValueError('Label mismatch (possibly old run)')
        if not (part.gold_label.astype(int).to_numpy()==part.item_id.map(look.gold_label).to_numpy()).all():
            raise ValueError('Gold label mismatch')
        if not (part.text_sha256.values==part.item_id.map(lambda x:sha(look.loc[x,LANG_COL[language]])).values).all():
            raise ValueError('Text-hash mismatch')
        check=-part.log_likelihood/(part.n_bytes*np.log(2))
        if not np.allclose(check.values,part.bpb.values,rtol=1e-5,atol=1e-6):raise ValueError('BPB formula mismatch')
    return True

def require_complete_scores(scores,model_labels=('LLaMA','PersianLLaMA'),n_prompts=None):
    # n_prompts is checked at model-language granularity; allow one-model diagnostics.
    d=scores.copy()
    if d.duplicated(['item_id','language','model']).any():raise ValueError('Duplicate score keys')
    for model in model_labels:
        for lang in LANG_COL:
            subset=d[(d.model==model)&(d.language==lang)]
            if n_prompts is not None and len(subset)!=3*n_prompts:
                raise ValueError(f'Incomplete {model}/{lang}: {len(subset)} instead of {3*n_prompts}')
    if not np.isfinite(d[['bpb','log_likelihood','log_ppl_token']]).all().all():raise ValueError('Nonfinite metrics')
    return d

def paired_metrics(scores):
    """Positive gap_bpb means *higher* stereotype likelihood per UTF-8 byte.
    Labels come ONLY from official gold_label. One prompt=one paired observation.
    """
    s=require_complete_scores(scores)
    keys=['prompt_id','model','language','bias_type']
    if s.groupby(keys).label_name.nunique().ne(3).any():raise ValueError('Incomplete/duplicated prompt labels')
    p=s.pivot(index=keys,columns='label_name',values=['bpb','log_ppl_token','log_likelihood'])
    p.columns=[a+'_'+b.replace('-','_') for a,b in p.columns];p=p.reset_index()
    p['gap_bpb']=p['bpb_anti_stereotype']-p['bpb_stereotype']
    p['stereotype_preference']=np.where(p.gap_bpb>1e-10,1,np.where(p.gap_bpb< -1e-10,0,np.nan))
    p['log_ppl_ratio']=p.log_ppl_token_anti_stereotype-p.log_ppl_token_stereotype
    p['apx_signed']=np.expm1(p.log_ppl_ratio.clip(-700,700))
    disp=s.groupby(keys).bpb.agg(lambda x:float(np.var(x,ddof=0))).rename('triplet_dispersion_bpb').reset_index()
    return p.merge(disp,on=keys,validate='one_to_one')

def token_summary(scores):
    s=require_complete_scores(scores)
    out=s.groupby(['model','language']).agg(items=('item_id','size'),avg_content_tokens=('n_content_tokens','mean'),
        total_chars=('n_chars','sum'),total_tokens=('n_content_tokens','sum'),total_bytes=('n_bytes','sum'),
        mean_bpb=('bpb','mean'),median_ppl_token=('ppl_token','median')).reset_index()
    out['corpus_cpt']=out.total_chars/out.total_tokens
    out['corpus_bytes_per_token']=out.total_bytes/out.total_tokens
    return out

def build_optional_slot_queue(df):
    """Strict English BLANK reconstruction only; failed rows flagged, Persian slots require humans.
    No unverified inferred Persian templates are used in model evaluation.
    """
    d=clean_dataset(df)
    rows=[]
    for _,r in d.iterrows():
        prefix,suffix=(r.context.split('BLANK',1) if r.context.count('BLANK')==1 else (None,None))
        en=r['English Sentence']
        match=(prefix is not None and en.startswith(prefix) and en.endswith(suffix)
               and len(en)>=len(prefix)+len(suffix))
        cand=en[len(prefix):len(en)-len(suffix) if suffix else None] if match else ''
        rows.append(dict(item_id=r.item_id,prompt_id=r.prompt_id,context_en=r.context,
             full_en=en,english_prefix=prefix or '',english_suffix=suffix or '',
             candidate_en=cand,exact_english_slot_match=int(bool(match)),
             template_persian_VALIDATED='',candidate_persian_VALIDATED='',
             translated_slot_review_status='PENDING',human_notes=''))
    return pd.DataFrame(rows)



