import json
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import numpy as np
import pandas as pd
from bias_stats import hierarchical_models


def test_mixedlm_prompt_clustering_and_optimizers(tmp_path):
    rng = np.random.default_rng(123)
    rows = []
    for i in range(240):
        p = f'p{i:03d}'
        cat = ['gender', 'race', 'religion', 'profession'][i // 60]
        u = rng.normal(0, 0.1)
        for model in ['LLaMA', 'PersianLLaMA']:
            for lang in ['English', 'Persian']:
                v = 0.07 + u + (model == 'PersianLLaMA') * 0.005 + (lang == 'Persian') * -0.03 + rng.normal(0, 0.1)
                rows.append({'prompt_id':p,'bias_type':cat,'model':model,'language':lang,'gap_bpb':v})
    d = pd.DataFrame(rows)
    result = hierarchical_models(d, tmp_path)
    assert result['mixed_model'] == 'success'
    assert result['n_clusters'] == 240
    assert 0 <= result['icc_random_intercept'] <= 1
    assert result['gee_sensitivity_run']
    assert (tmp_path / 'mixed_effects_fixed_effects.csv').exists()
    assert (tmp_path / 'mixedlm_optimizer_trials.csv').exists()
    assert (tmp_path / 'gee_fixed_effects.csv').exists()
    assert 'random_intercept_variance' in json.loads((tmp_path / 'model_fit_status.json').read_text())
