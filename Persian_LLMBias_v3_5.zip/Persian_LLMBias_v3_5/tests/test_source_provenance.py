"""Synthetic source fixtures only; DO NOT confuse with official HF verification."""
import unittest,tempfile,sys
from pathlib import Path
import pandas as pd
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from source_provenance import reconcile,require_verified_source
from bias_core import clean_dataset

class SourceReconciliationTests(unittest.TestCase):
    def mock(self):
        rows=[]; canonical=[]
        for i in range(4):
            ctx=f'Group {i} is BLANK.'
            trip=[]
            for code,label in [(0,'anti-stereotype'),(1,'stereotype'),(2,'unrelated')]:
                text=f'Group {i} is {label}.'
                trip.append((text,code))
                rows.append(dict(bias_type='race',target=f'group{i}',context=ctx,
                    gold_label=code,**{'English Sentence':text,'Persian Sentence':f'ترجمه {i} {code}'}))
            canonical.append(dict(id=f'official-{i}',context=ctx,target=f'group{i}',bias_type='race',
                sentences={'sentence':[x for x,_ in trip], 'gold_label':[c for _,c in trip],
                           'id':[f'official-{i}-{c}' for _,c in trip]}))
        return clean_dataset(pd.DataFrame(rows)),canonical
    def test_full_exact_match_and_ids(self):
        d,records=self.mock()
        with tempfile.TemporaryDirectory() as tmp:
            result=reconcile(d,{'intrasentence':records,'intersentence':[]},'a'*40,output_dir=tmp)
            self.assertEqual(result['status'],'VERIFIED')
            self.assertEqual(result['verified_config'],'intrasentence')
            result_csv=pd.read_csv(Path(tmp)/'dataset_verified_with_source_ids_v3_2.csv')
            self.assertEqual(len(result_csv),12)
            self.assertEqual(result_csv.source_prompt_id.nunique(),4)
            self.assertEqual(result_csv.source_item_id.nunique(),12)
            self.assertEqual(require_verified_source(result_csv,Path(tmp)/'source_verified_manifest_v3_2.json')['status'],'VERIFIED')
    def test_different_gold_fails_closed(self):
        d,records=self.mock()
        records[0]['sentences']['gold_label'][0]=1
        with tempfile.TemporaryDirectory() as tmp:
            result=reconcile(d,{'intrasentence':records,'intersentence':[]},'b'*40,output_dir=tmp)
            self.assertEqual(result['status'],'UNVERIFIED')
            self.assertFalse((Path(tmp)/'dataset_verified_with_source_ids_v3_2.csv').exists())
            with self.assertRaises(FileNotFoundError):require_verified_source(d,Path(tmp)/'source_verified_manifest_v3_2.json')
    def test_both_configs_ambiguous(self):
        d,records=self.mock()
        with tempfile.TemporaryDirectory() as tmp:
            result=reconcile(d,{'intrasentence':records,'intersentence':records},'c'*40,output_dir=tmp)
            self.assertEqual(result['status'],'AMBIGUOUS')
            self.assertFalse((Path(tmp)/'dataset_verified_with_source_ids_v3_2.csv').exists())

if __name__=='__main__':unittest.main()
