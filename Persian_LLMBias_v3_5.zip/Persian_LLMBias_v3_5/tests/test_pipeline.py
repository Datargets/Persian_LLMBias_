"""CPU-only structural/method tests. Synthetic numbers are NEVER paper findings."""
import sys, unittest, math, tempfile
from pathlib import Path
import pandas as pd, numpy as np
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from bias_core import (clean_dataset,dataset_audit,paired_metrics,token_summary,score_sentence,
  generate_blind_review_files,annotation_report,build_optional_slot_queue,LABEL_FROM_GOLD)
from bias_stats import directional_bias_table,model_contrast_table,cross_language_contrast_table


def mock_data(n_per_cat=3):
  rows=[];results=[]
  rng=np.random.default_rng(44)
  for cat in ['race','gender','religion','profession']:
    for i in range(n_per_cat):
      c=f'{cat} and group{i} are BLANK.'
      for gold in [0,1,2]:
        label=LABEL_FROM_GOLD[gold]
        rows.append({'bias_type':cat,'context':c,'gold_label':gold,
          'label_name':{'stereotype':'anti-stereotype','anti-stereotype':'stereotype','unrelated':'unrelated'}[label],
          'English Sentence':c.replace('BLANK',f'{gold}-{i}'),
          'Persian Sentence':f'جمله فارسی {cat} {i} {gold}', 'target':'test'})
  d=clean_dataset(pd.DataFrame(rows))
  for r in d.itertuples(index=False):
    for model in ['LLaMA','PersianLLaMA']:
      for lang in ['English','Persian']:
        bpb=2+rng.normal(0,.01)+{'stereotype':0,'anti-stereotype':.15,'unrelated':.03}[r.label_name]
        nt=6;nb=30;nc=18;nl=bpb*nb*math.log(2)
        results.append(dict(item_id=r.item_id,prompt_id=r.prompt_id,model=model,language=lang,
          bias_type=r.bias_type,label_name=r.label_name,gold_label=r.gold_label,
          log_likelihood=-nl,n_content_tokens=nt,n_bytes=nb,n_chars=nc,bpb=bpb,
          log_ppl_token=nl/nt,ppl_token=math.exp(nl/nt),cpt=nc/nt,bytes_per_token=nb/nt,run_id='test'))
  return d,pd.DataFrame(results)

class Tests(unittest.TestCase):
  def test_correct_raw_gold_mapping(self):
    d,_=mock_data()
    self.assertTrue((d.gold_label.map(LABEL_FROM_GOLD)==d.label_name).all())
    self.assertEqual(dataset_audit(d)['legacy_label_mismatches'],24)
  def test_label_independent_item_id(self):
    d,_=mock_data()
    a=d.copy();a['label_name']='wrong'  # ignored, derives gold_label
    self.assertEqual(d.item_id.tolist(),clean_dataset(a).item_id.tolist())
  def test_triplet_direction(self):
    d,score=mock_data()
    p=paired_metrics(score)
    self.assertEqual(len(p),4*3*2*2)
    self.assertGreater(p.gap_bpb.mean(),0)
    self.assertEqual(len(d),36)
  def test_statistical_test_families(self):
    _,score=mock_data()
    pair=paired_metrics(score)
    a=directional_bias_table(pair,n_boot=15,n_perm=50)
    b=model_contrast_table(pair,n_boot=15,n_perm=50)
    c=cross_language_contrast_table(pair,n_boot=15,n_perm=50)
    self.assertEqual((len(a),len(b),len(c)),(16,8,8))
    self.assertTrue(((a.p_adjusted_holm>=0)&(a.p_adjusted_holm<=1)).all())
  def test_reject_missing_triplet(self):
    d,_=mock_data()
    with self.assertRaises(ValueError):clean_dataset(d.iloc[:-1])
  def test_blind_review_and_pending(self):
    d,_=mock_data()
    with tempfile.TemporaryDirectory() as temp:
      files=generate_blind_review_files(d,temp)
      self.assertEqual(len(files),3)
      combined=pd.concat([pd.read_csv(f) for f in files],ignore_index=True)
      self.assertNotIn('label_name',combined.columns)
      self.assertNotIn('gold_label',combined.columns)
      self.assertEqual(annotation_report(combined,expected_item_ids=set(d.item_id))['status'],'PENDING')
  def test_english_slot_exact_match(self):
    d,_=mock_data()
    q=build_optional_slot_queue(d)
    self.assertEqual(q.exact_english_slot_match.sum(),len(d))
  def test_scoring_math(self):
    import torch
    class TK:
      bos_token_id=0
      def __call__(self,text,add_special_tokens=False):return {'input_ids':[1,2,3]}
    class M(torch.nn.Module):
      config=type('Cfg',(),{'max_position_embeddings':30})()
      def __init__(self):super().__init__();self.emb=torch.nn.Embedding(4,8)
      def get_input_embeddings(self):return self.emb
      def forward(self,input_ids,use_cache=False):
        return type('O',(),{'logits':torch.zeros((1,input_ids.size(1),4))})()
    r=score_sentence(M(),TK(),'abc')
    self.assertAlmostEqual(r['log_likelihood'],-3*math.log(4),places=5)
    self.assertAlmostEqual(r['bpb'],2.0)
    self.assertAlmostEqual(r['ppl_token'],4.0)

if __name__=='__main__':unittest.main()
