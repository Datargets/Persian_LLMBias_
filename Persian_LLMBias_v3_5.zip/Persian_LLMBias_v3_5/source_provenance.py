"""Auditable provenance reconciliation for translated StereoSet subset.

No inference from BLANK alone. Exact records (context, candidate text,
gold_label) are matched to BOTH official StereoSet configurations. Independent
translation validation is a separate human procedure.
"""
from __future__ import annotations
import json, hashlib
from pathlib import Path
from collections import defaultdict
import pandas as pd
from bias_core import clean_dataset, dataset_digest

PROVENANCE_VERSION = 'v3.2.2-triplet-id-repair'
DATASET_ID = 'McGill-NLP/stereoset'
CONFIGS = ('intrasentence', 'intersentence')
LABELS = {'anti-stereotype':0, 'stereotype':1, 'unrelated':2}

def label_int(x):
    if isinstance(x, str):
        if x.strip().lower() in LABELS:
            return LABELS[x.strip().lower()]
        return int(x)
    return int(x)

def load_canonical(*, revision=None):
    from datasets import load_dataset
    from huggingface_hub import HfApi
    api = HfApi()
    sha = api.dataset_info(DATASET_ID, revision=revision or 'bf6e7ce50491784d094fb7afe60a70ecccb89035').sha
    output = {}
    for config in CONFIGS:
        ds = load_dataset(DATASET_ID, config, split='validation', revision=sha)
        output[config] = list(ds)
    return output, sha

def canonical_records(rows,config):
    bykey=defaultdict(list)
    triples={}
    context_ids={}
    for record in rows:
        rid=str(record['id']); context=str(record['context'])
        bias_type=str(record['bias_type'])
        context_ids.setdefault((bias_type,context),set()).add(rid)
        s=record['sentences']
        for en, gold, sid in zip(s['sentence'], s['gold_label'], s['id']):
            k=(bias_type, context,str(en))
            bykey[k].append(dict(source_config=config,source_prompt_id=rid,source_item_id=str(sid),source_gold_label=label_int(gold),source_target=str(record['target'])))
        triples[rid] = (bias_type, context, tuple(sorted((str(en),label_int(g)) for en,g in zip(s['sentence'],s['gold_label']))))
    return bykey,triples,context_ids

def reconcile(df, official,commit_sha, *, output_dir):
    """Produce evidence without changing original labels or translations."""
    d=clean_dataset(df)
    out=Path(output_dir);out.mkdir(parents=True,exist_ok=True)
    per_config={}
    all_matches=[]
    src_triplet = {pid:(part['bias_type'].iloc[0],part['context'].iloc[0],
        tuple(sorted((str(x),int(y)) for x,y in zip(part['English Sentence'],part['gold_label']))))
        for pid,part in d.groupby('prompt_id',sort=False)}
    for config in CONFIGS:
        records=official[config]
        lookup,triples,ctxs=canonical_records(records,config)
        triplet_rev=defaultdict(list)
        for rid,key in triples.items():triplet_rev[key].append(rid)
        exact_prompt_ids={pid:triplet_rev.get(value,[]) for pid,value in src_triplet.items()}
        count_exact_prompts=sum(len(v)==1 for v in exact_prompt_ids.values())
        count_ambiguous=sum(len(v)>1 for v in exact_prompt_ids.values())
        key_matches=[]
        for _,r in d.iterrows():
            k=(str(r['bias_type']),str(r['context']),str(r['English Sentence']))
            candidates=lookup.get(k,[])
            same_gold=[x for x in candidates if x['source_gold_label']==int(r['gold_label'])]
            triplet_prompt_ids = exact_prompt_ids.get(r.prompt_id, [])
            within_prompt = (
                [x for x in same_gold if x['source_prompt_id']==triplet_prompt_ids[0]]
                if len(triplet_prompt_ids)==1 else []
            )
            match = within_prompt[0] if len(within_prompt)==1 else {}
            key_matches.append(dict(item_id=r.item_id,prompt_id=r.prompt_id,source_config=config,
                exact_context_candidate=int(bool(candidates)),exact_label_match=int(bool(within_prompt)),
                source_gold_label=match.get('source_gold_label',''),source_prompt_id=match.get('source_prompt_id',''),
                source_item_id=match.get('source_item_id',''),source_target=match.get('source_target',''),
                candidate_collisions=len(candidates),label_mismatches=len(candidates)-len(same_gold),
                prompt_triplet_match=int(len(exact_prompt_ids.get(r.prompt_id,[]))==1)))
        km=pd.DataFrame(key_matches)
        km.to_csv(out/f'canonical_matches_{config}.csv',index=False,encoding='utf-8-sig')
        all_matches.append(km)
        # Reproduce the original notebook's category-wise pandas.sample(60, random_state=42).
        # This is a SEPARATE check: provenance may be valid even if historic sampling cannot be reproduced.
        sampled={}; sampler_exact=None
        if len(d)==720 and d.prompt_id.nunique()==240:
            official_frame=pd.DataFrame([{'id':str(r['id']),'bias_type':str(r['bias_type'])} for r in records])
            sampled_ok=True
            for category in ('race','gender','religion','profession'):
                cat=official_frame[official_frame.bias_type==category]
                if len(cat)<60:sampled_ok=False;continue
                expected=set(cat.sample(n=60,random_state=42)['id'])
                cat_items=d.loc[d.bias_type==category,'item_id']
                actual=set(km.loc[km.item_id.isin(cat_items),'source_prompt_id'].astype(str))- {''}
                sampled[category]=dict(expected_n=len(expected),actual_matched_n=len(actual),overlap_n=len(actual & expected),exact_same_selected_prompt_ids=bool(actual==expected))
            if sampled_ok:sampler_exact=bool(all(v['exact_same_selected_prompt_ids'] for v in sampled.values()))
        per_config[config] = dict(
            original_notebook_sampling_exactly_reproduced=sampler_exact,
            category_sampler_comparison=sampled,
            official_prompts=len(records),official_contexts=len(ctxs),
            matched_context_candidate=int(km.exact_context_candidate.sum()),
            matched_context_candidate_label=int(km.exact_label_match.sum()),
            matched_whole_triplet_prompts=int(count_exact_prompts),
            ambiguous_whole_triplet_prompts=int(count_ambiguous),
            source_id_pairs_unique=int(km.loc[km.source_item_id.ne(''), 'source_item_id'].nunique()),
            full_exact_match=bool(
                len(km) == len(d)
                and km.exact_label_match.eq(1).all()
                and km.source_item_id.ne('').all()
                and km.source_prompt_id.ne('').all()
                and km.source_item_id.nunique() == len(d)
                and km.source_prompt_id.nunique() == d.prompt_id.nunique()
                and count_exact_prompts == int(d.prompt_id.nunique())
                and count_ambiguous == 0
            ),
        )
    confirmed=[name for name,v in per_config.items() if v['full_exact_match']]
    status='VERIFIED' if len(confirmed)==1 else ('AMBIGUOUS' if len(confirmed)>1 else 'UNVERIFIED')
    base=dict(status=status,dataset_id=DATASET_ID,commit_sha=commit_sha,split='validation',
              verified_config=confirmed[0] if len(confirmed)==1 else None,
              dataset_sha256=dataset_digest(d),local_prompts=int(d.prompt_id.nunique()),local_candidates=len(d),
              configs=per_config,statement='Config is VERIFIED only when all source triplets / English candidates match the same canonical configuration exactly. Historical random sampling is assessed separately.',
              full_sentence_scoring='Current model scoring remains adapted FULL-SENTENCE CAUSAL likelihood, not official StereoSet completion / leaderboard scoring.',
              independent_human_review='ONE_LINGUIST_TRANSLATION_AUDIT; NO_IAA',persian_translation_review={'reviewer_count':1,'evaluated_sentences':720,'flagged_sentences':145,'modified_sentences':132})
    (out/'source_reconciliation_v3_2.json').write_text(json.dumps(base,indent=2,ensure_ascii=False),encoding='utf8')
    if status=='VERIFIED':
        chosen=all_matches[CONFIGS.index(confirmed[0])]
        # Drop inherited canonical fields before recomputing exact references on re-audit.
        # Otherwise pandas merge introduces _x/_y columns and corrupts the rerun output.
        stripped=d.drop(columns=['source_prompt_id','source_item_id','source_config','source_target',
                                'source_config_status','canonical_dataset_commit_sha'],errors='ignore')
        verified=stripped.merge(chosen[['item_id','source_prompt_id','source_item_id','source_config','source_target']],
                                on='item_id',validate='one_to_one')
        verified['source_config_status']='VERIFIED_CANONICAL_EXACT_MATCH'
        verified['canonical_dataset_commit_sha']=commit_sha
        (out/'source_verified_manifest_v3_2.json').write_text(json.dumps(base,indent=2,ensure_ascii=False),encoding='utf8')
        verified.to_csv(out/'dataset_verified_with_source_ids_v3_2.csv',index=False,encoding='utf-8-sig')
    else:
        # Do not leave an obsolete VERIFIED manifest or dataset from an earlier run.
        for stale_name in ('source_verified_manifest_v3_2.json',
                           'dataset_verified_with_source_ids_v3_2.csv'):
            stale = out / stale_name
            if stale.exists():
                stale.unlink()
        unmatched=d[['prompt_id','item_id','context','English Sentence','gold_label']].copy()
        for cfg,cm in zip(CONFIGS,all_matches):
            unmatched[f'{cfg}_exact']=cm['exact_label_match'].to_numpy()
        unmatched=unmatched[~unmatched[[f'{cfg}_exact' for cfg in CONFIGS]].any(axis=1)]
        unmatched.to_csv(out/'unmatched_for_manual_reconciliation.csv',index=False,encoding='utf-8-sig')
    return base

def require_verified_source(df,manifest_path):
    p=Path(manifest_path)
    if not p.is_file():
        raise FileNotFoundError('Run Source_Provenance_Audit.ipynb FIRST. Missing '+str(p))
    meta=json.loads(p.read_text(encoding='utf8'))
    if meta.get('status')!='VERIFIED':
        raise ValueError('Dataset source NOT VERIFIED; do not start GPU model scoring.')
    if (meta.get('configs', {}).get(meta.get('verified_config'), {})
            .get('source_id_pairs_unique') != len(clean_dataset(df))):
        raise ValueError('Verified manifest has incomplete canonical source IDs. Re-run source audit.')
    if meta.get('dataset_sha256')!=dataset_digest(df):
        raise ValueError('Dataset content differs from source-audited dataset! Re-run source audit.')
    return meta
