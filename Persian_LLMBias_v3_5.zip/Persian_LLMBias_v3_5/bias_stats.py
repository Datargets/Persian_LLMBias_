"""Prompt-clustered inference for reviewer-requested directional bias comparisons."""
from __future__ import annotations
import json, warnings
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from statsmodels.stats.multitest import multipletests


def bootstrap_mean_ci(values,n_boot=2500,seed=42,alpha=.05):
    x=np.asarray(values,float); x=x[np.isfinite(x)]
    if not len(x): return (np.nan,np.nan)
    rng=np.random.default_rng(seed)
    if len(x)==1:return (float(x[0]),float(x[0]))
    means=np.array([rng.choice(x,size=len(x),replace=True).mean() for _ in range(n_boot)])
    return tuple(np.quantile(means,[alpha/2,1-alpha/2]))


def bootstrap_rate_ci(values,n_boot=2500,seed=42):
    x=np.asarray(values,float); x=x[np.isfinite(x)]
    if not len(x):return (np.nan,np.nan)
    rng=np.random.default_rng(seed)
    rates=np.array([rng.choice(x,size=len(x),replace=True).mean() for _ in range(n_boot)])
    return tuple(np.quantile(rates,[.025,.975]))


def signed_test(x,seed=42,n_perm=20000,n_boot=2500):
    """Two-sided sign-flip permutation, Wilcoxon, standardized paired effect.

    Tests signed stereotype bias != 0 across independent *prompts*.
    """
    x=np.asarray(x,dtype=float); x=x[np.isfinite(x)]; n=len(x)
    if n<2:return {'n_prompts':n,'mean_gap_bpb':np.nan,'median_gap_bpb':np.nan,'sd_gap_bpb':np.nan,
                   'cohen_dz':np.nan,'ci_lower':np.nan,'ci_upper':np.nan,'permutation_p':np.nan,'wilcoxon_p':np.nan}
    obs=abs(x.mean()); rng=np.random.default_rng(seed)
    count=0
    # Grouping at prompt level; avoid huge n_perm x n arrays.
    for _ in range(n_perm):
        if abs((x*rng.choice([-1,1],size=n)).mean())>=obs-1e-15:count+=1
    p=(count+1)/(n_perm+1)
    try: pw=float(stats.wilcoxon(x,alternative='two-sided',zero_method='wilcox').pvalue)
    except ValueError: pw=np.nan
    sd=float(x.std(ddof=1));lo,hi=bootstrap_mean_ci(x,n_boot,seed)
    return {'n_prompts':n,'mean_gap_bpb':float(x.mean()),'median_gap_bpb':float(np.median(x)),
            'sd_gap_bpb':sd,'cohen_dz':float(x.mean()/sd) if sd>0 else np.nan,
            'ci_lower':lo,'ci_upper':hi,'permutation_p':p,'wilcoxon_p':pw}


def _correct_family(df, p_col='permutation_p',method='holm'):
    out=df.copy(); out['p_adjusted_holm']=np.nan; out['reject_05_holm']=False
    mask=out[p_col].notna()
    if mask.sum():
        r,p,_,_=multipletests(out.loc[mask,p_col],alpha=.05,method=method)
        out.loc[mask,'p_adjusted_holm']=p;out.loc[mask,'reject_05_holm']=r
    return out


def directional_bias_table(pairs,n_boot=2500,n_perm=20000,seed=42):
    rows=[]
    for i,((category,lang,model),part) in enumerate(pairs.groupby(['bias_type','language','model'],sort=True)):
        r={'bias_type':category,'language':lang,'model':model}
        r.update(signed_test(part.gap_bpb,n_boot=n_boot,n_perm=n_perm,seed=seed+i))
        non_ties=part.stereotype_preference.dropna().to_numpy()
        r['preference_rate']=float(non_ties.mean()) if len(non_ties) else np.nan
        r['non_ties']=int(len(non_ties));r['pref_ci_lower'],r['pref_ci_upper']=bootstrap_rate_ci(non_ties,n_boot,seed+i)
        r['mean_triplet_dispersion_bpb']=float(part.triplet_dispersion_bpb.mean())
        r['mean_log_ppl_ratio_diagnostic']=float(part.log_ppl_ratio.mean())
        rows.append(r)
    table=_correct_family(pd.DataFrame(rows))
    if len(table)!=16: warnings.warn(f'{len(table)} primary cells (expected 16 for 4 categories x 2 languages x 2 models)')
    return table


def model_contrast_table(pairs,n_boot=2500,n_perm=20000,seed=42):
    keys=['prompt_id','language','bias_type']
    p=pairs.pivot(index=keys,columns='model',values='gap_bpb')
    if not {'LLaMA','PersianLLaMA'}.issubset(p.columns):raise ValueError('Need scores for both models')
    p=p.dropna(subset=['LLaMA','PersianLLaMA']).reset_index()
    p['difference_persianllama_minus_llama']=p['PersianLLaMA']-p['LLaMA']
    rows=[]
    for i,((cat,language),g) in enumerate(p.groupby(['bias_type','language'])):
        r={'bias_type':cat,'language':language}
        r.update(signed_test(g['difference_persianllama_minus_llama'],seed=seed+i,n_boot=n_boot,n_perm=n_perm))
        rows.append(r)
    return _correct_family(pd.DataFrame(rows))


def cross_language_contrast_table(pairs,n_boot=2500,n_perm=20000,seed=42):
    p=pairs.pivot(index=['prompt_id','model','bias_type'],columns='language',values='gap_bpb').dropna(subset=['English','Persian']).reset_index()
    p['difference_persian_minus_english']=p.Persian-p.English
    rows=[]
    for i,((cat,model),g) in enumerate(p.groupby(['bias_type','model'])):
        r={'bias_type':cat,'model':model}
        r.update(signed_test(g['difference_persian_minus_english'],seed=seed+i,n_boot=n_boot,n_perm=n_perm))
        rows.append(r)
    return _correct_family(pd.DataFrame(rows))


def category_variation_table(pairs):
    """Kruskal–Wallis on prompt-level signed gaps; descriptive category variation, not causal."""
    rows=[]
    for (model,language),g in pairs.groupby(['model','language']):
        groups=[p.gap_bpb.to_numpy() for _,p in g.groupby('bias_type')]
        stat,p=stats.kruskal(*groups) if len(groups)>1 else (np.nan,np.nan)
        rows.append({'model':model,'language':language,'kruskal_h':stat,'p_value':p,'n_prompts':len(g)})
    return _correct_family(pd.DataFrame(rows).rename(columns={'p_value':'permutation_p'})).rename(columns={'permutation_p':'kruskal_p'})


def hierarchical_models(pairs, out_dir):
    """Fit a prompt-random-intercept MixedLM with documented optimizer trials,
    plus an independent prompt-clustered GEE sensitivity analysis.

    No silent substitution: GEE and MixedLM are distinct estimands/SE methods;
    both output files are labeled separately. All rows are prompt-paired gaps
    (2 models x 2 languages per prompt, category fixed within prompt).
    """
    import statsmodels.formula.api as smf
    import statsmodels.api as sm
    import time

    output = Path(out_dir)
    output.mkdir(exist_ok=True, parents=True)
    formula = 'gap_bpb ~ C(model)*C(language)*C(bias_type)'
    required = ['prompt_id', 'gap_bpb', 'model', 'language', 'bias_type']
    for col in required:
        if col not in pairs.columns:
            raise ValueError('Missing MixedLM column: ' + col)
    frame = pairs[required].copy()
    if frame.isna().any().any() or not np.isfinite(frame['gap_bpb']).all():
        raise ValueError('MixedLM data contain missing/nonfinite values')
    counts = frame.groupby('prompt_id').size()
    if len(frame) != 960 or len(counts) != 240 or not counts.eq(4).all():
        raise ValueError('Expected 240 prompt clusters with exactly four observations each')
    if not frame.groupby('prompt_id').bias_type.nunique().eq(1).all():
        raise ValueError('Bias category must be fixed within prompt')

    model = smf.mixedlm(formula, data=frame, groups=frame['prompt_id'], re_formula='1')
    attempts, successful = [], []
    for optimizer in ('bfgs', 'cg', 'powell', 'lbfgs'):
        started = time.monotonic()
        try:
            with warnings.catch_warnings(record=True) as observed:
                warnings.simplefilter('always')
                fit = model.fit(reml=False, method=optimizer, maxiter=600, disp=False)
            w = [str(item.message) for item in observed]
            re_var = float(fit.cov_re.iloc[0, 0])
            residual_var = float(fit.scale)
            valid = (bool(fit.converged) and np.isfinite(fit.llf)
                     and np.isfinite(re_var) and re_var > 1e-8
                     and np.isfinite(residual_var) and residual_var > 0
                     and np.isfinite(fit.fe_params.to_numpy()).all()
                     and np.isfinite(fit.bse_fe.to_numpy()).all())
            attempts.append({'optimizer': optimizer, 'success': valid,
                'converged': bool(fit.converged), 'log_likelihood': float(fit.llf),
                'random_intercept_variance': re_var, 'residual_variance': residual_var,
                'aic': float(fit.aic), 'seconds': round(time.monotonic()-started, 3),
                'warnings': '; '.join(w), 'error': ''})
            if valid:
                successful.append((optimizer, fit))
        except Exception as error:
            attempts.append({'optimizer': optimizer, 'success': False, 'converged': False,
                'log_likelihood': np.nan, 'random_intercept_variance': np.nan,
                'residual_variance': np.nan, 'aic': np.nan,
                'seconds': round(time.monotonic()-started, 3), 'warnings': '',
                'error': repr(error)})
    pd.DataFrame(attempts).to_csv(output/'mixedlm_optimizer_trials.csv', index=False)

    status = {'formula': formula, 'random_intercept': 'prompt_id',
              'n_observations': len(frame), 'n_clusters': len(counts),
              'method': 'maximum likelihood (REML=False)',
              'mixed_model': 'FAILED', 'mixed_model_reason': 'No optimizer converged to a valid solution',
              'gee_sensitivity_run': False}
    if successful:
        # Prefer BFGS, otherwise choose the converged optimizer with the highest log-likelihood.
        selected = next(((o, f) for o, f in successful if o=='bfgs'), None)
        if selected is None:
            selected = max(successful, key=lambda item: item[1].llf)
        chosen_opt, fitted = selected
        agrees = all(np.allclose(fitted.fe_params.to_numpy(), other.fe_params.to_numpy(),
                                 atol=1e-4, rtol=1e-4)
                     and abs(float(fitted.llf-other.llf)) < 1e-3
                     for _, other in successful)
        random_var = float(fitted.cov_re.iloc[0,0])
        residual_var = float(fitted.scale)
        interval = fitted.conf_int().loc[fitted.fe_params.index]
        coef = pd.DataFrame({
           'term': fitted.fe_params.index,
           'estimate': fitted.fe_params.to_numpy(),
           'std_error': fitted.bse_fe.to_numpy(),
           'z_statistic': (fitted.fe_params/fitted.bse_fe).to_numpy(),
           'p_value': fitted.pvalues.loc[fitted.fe_params.index].to_numpy(),
           'ci_lower_95': interval.iloc[:,0].to_numpy(),
           'ci_upper_95': interval.iloc[:,1].to_numpy()
        })
        coef.to_csv(output/'mixed_effects_fixed_effects.csv',index=False)
        fitted.params.to_csv(output/'mixed_effects_coefficients.csv',header=['estimate'])
        (output/'mixed_effects_summary.txt').write_text(str(fitted.summary()),encoding='utf8')
        status.update({'mixed_model':'success', 'mixed_model_reason':None,
            'selected_optimizer':chosen_opt, 'converged':True,
            'optimizer_estimates_agree':bool(agrees), 'n_successful_optimizers':len(successful),
            'random_intercept_variance':random_var, 'residual_variance':residual_var,
            'icc_random_intercept':random_var/(random_var+residual_var),
            'log_likelihood':float(fitted.llf), 'aic':float(fitted.aic)})
        (output/'mixed_effects_diagnostics.json').write_text(json.dumps(status,indent=2),encoding='utf8')

    # Always produce GEE sensitivity estimates independently (not a disguised fallback).
    with warnings.catch_warnings(record=True) as gee_warnings:
        warnings.simplefilter('always')
        gee = smf.gee(formula, groups='prompt_id', data=frame,
            cov_struct=sm.cov_struct.Exchangeable(),
            family=sm.families.Gaussian()).fit()
    (output/'gee_prompt_cluster_summary.txt').write_text(str(gee.summary()),encoding='utf8')
    gee.params.to_csv(output/'gee_coefficients.csv',header=['estimate'])
    gee_table = pd.DataFrame({'term':gee.params.index,
        'estimate':gee.params.to_numpy(), 'robust_std_error':gee.bse.to_numpy(),
        'p_value':gee.pvalues.to_numpy(),
        'ci_lower_95':gee.conf_int().iloc[:,0].to_numpy(),
        'ci_upper_95':gee.conf_int().iloc[:,1].to_numpy()})
    gee_table.to_csv(output/'gee_fixed_effects.csv',index=False)
    status['gee_sensitivity_run'] = True
    status['gee_converged'] = bool(gee.converged)
    status['gee_warnings'] = [str(w.message) for w in gee_warnings]
    if successful:
        comparison = coef[['term','estimate','p_value']].merge(
            gee_table[['term','estimate','p_value']],on='term',suffixes=('_mixedlm','_gee'))
        comparison.to_csv(output/'mixed_vs_gee_fixed_effects.csv',index=False)
    (output/'model_fit_status.json').write_text(json.dumps(status,indent=2),encoding='utf8')
    return status


def full_statistics(scores,out_dir,n_boot=2500,n_perm=20000,seed=42,dataset=None):
    from bias_core import paired_metrics,token_summary,require_complete_scores,verify_scores,clean_dataset
    output=Path(out_dir);output.mkdir(parents=True,exist_ok=True)
    if dataset is None: raise ValueError("Pass the source dataset for hash, gold_label, and model completeness validation")
    verify_scores(scores,dataset)
    scores=require_complete_scores(scores,n_prompts=240)
    pairs=paired_metrics(scores)
    if len(pairs)!=240*2*2:raise ValueError('Expected exactly 960 prompt x model x language pairs')
    pairs.to_csv(output/'prompt_level_metrics.csv',index=False)
    tab=directional_bias_table(pairs,n_boot,n_perm,seed)
    tab.to_csv(output/'table_directional_bias_16_tests_holm.csv',index=False)
    model=model_contrast_table(pairs,n_boot,n_perm,seed)
    model.to_csv(output/'table_model_contrasts_holm.csv',index=False)
    cross=cross_language_contrast_table(pairs,n_boot,n_perm,seed)
    cross.to_csv(output/'table_language_contrasts_holm.csv',index=False)
    cat=category_variation_table(pairs)
    cat.to_csv(output/'table_category_variation.csv',index=False)
    token_summary(scores).to_csv(output/'table_tokenization.csv',index=False)
    mixed=hierarchical_models(pairs,output)
    return pairs,{'primary_tests':tab,'model_contrasts':model,'language_contrasts':cross,
                  'category_variation':cat,'hierarchical_status':mixed}
