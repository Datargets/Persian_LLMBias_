#!/usr/bin/env python3
"""Strict independent audit of StereoSet source IDs, text and numeric/text labels.

Online: fetches pinned McGill-NLP/stereoset intrasentence/validation from HF.
Offline: uses archived verified English dataset; NOT a fresh HF verification.
Fail closed on mismatches. Reports audit CSV and JSON without modifying input.
"""
from __future__ import annotations
import argparse, json, sys
from collections import Counter
from pathlib import Path
import pandas as pd

LABELS={0:'anti-stereotype',1:'stereotype',2:'unrelated'}
DATASET='McGill-NLP/stereoset'
COMMIT='bf6e7ce50491784d094fb7afe60a70ecccb89035'


def read_data(path):
    p=Path(path)
    if p.suffix.lower() in {'.xlsx','.xls'}:
        d=pd.read_excel(p,sheet_name='Dataset_720',dtype={'Source prompt ID':'string','Source item ID':'string'})
        rename={'Source prompt ID':'source_prompt_id','Source item ID':'source_item_id',
                'English source':'English Sentence','Persian final v3.5':'Persian Sentence',
                'Gold label':'gold_label','Official label':'label_name','Category':'bias_type'}
        d=d.rename(columns=rename)
    else:
        d=pd.read_csv(p,dtype={'source_prompt_id':'string','source_item_id':'string'},encoding='utf-8-sig')
    required=['source_prompt_id','source_item_id','English Sentence','gold_label','label_name','bias_type','Persian Sentence']
    missing=sorted(set(required)-set(d.columns))
    if missing: raise ValueError('Missing required columns: '+', '.join(missing))
    if len(d)!=720: raise ValueError(f'Expected 720 rows; got {len(d)}')
    for c in ['source_prompt_id','source_item_id','English Sentence','label_name','bias_type','Persian Sentence']:
        if d[c].isna().any() or d[c].astype(str).str.strip().eq('').any():raise ValueError('Missing '+c)
    numeric=pd.to_numeric(d.gold_label,errors='raise')
    if numeric.isna().any() or (numeric%1!=0).any():raise ValueError('Non-integral or missing gold_label')
    d['gold_label']=numeric.astype(int)
    if not set(d.gold_label).issubset(LABELS):raise ValueError('Found illegal label IDs')
    if d.source_item_id.duplicated().any():raise ValueError('Duplicate source_item_id')
    return d


def official_online():
    from datasets import load_dataset
    ds=load_dataset(DATASET,'intrasentence',split='validation',revision=COMMIT)
    ref={}
    for row in ds:
        s=row['sentences']
        for sid, sentence, gold in zip(s['id'],s['sentence'],s['gold_label']):
            gold=int(gold)
            if gold not in LABELS:raise ValueError(f'Unexpected official gold label: {gold}')
            if sid in ref:raise ValueError(f'Duplicate official sentence ID {sid}')
            ref[sid]={'source_prompt_id':str(row['id']),'source_item_id':str(sid),
                      'English Sentence':str(sentence),'gold_label':gold,
                      'label_name':LABELS[gold],'bias_type':str(row['bias_type']),
                      'context':str(row['context']),'target':str(row['target'])}
    return ref


def official_offline(path):
    d=pd.read_csv(path,dtype={'source_item_id':'string','source_prompt_id':'string'},encoding='utf-8-sig')
    if len(d)!=720 or d.source_item_id.nunique()!=720:raise ValueError('Invalid offline snapshot')
    out={}
    for _,r in d.iterrows():
        out[str(r.source_item_id)]={k:r[k] for k in ['source_prompt_id','source_item_id','English Sentence','gold_label','bias_type','context','target']}
        out[str(r.source_item_id)]['gold_label']=int(r.gold_label)
        out[str(r.source_item_id)]['label_name']=LABELS[int(r.gold_label)]
    return out


def audit(data,ref):
    records=[]
    cmpcols=['source_prompt_id','English Sentence','gold_label','label_name','bias_type']
    # The official source also holds full prompt text and target.
    if 'context' in data.columns:cmpcols.append('context')
    if 'target' in data.columns:cmpcols.append('target')
    for i, r in data.iterrows():
        sid=str(r.source_item_id)
        refrow=ref.get(sid)
        issues=[]
        if refrow is None:issues.append('SOURCE_ITEM_ID_NOT_FOUND')
        else:
            for col in cmpcols:
                if str(r[col]).strip()!=str(refrow[col]).strip():issues.append('MISMATCH_'+col)
        val=LABELS.get(int(r.gold_label))
        if str(r.label_name).strip()!=val:issues.append('LOCAL_TEXT_NUMERIC_LABEL_MISMATCH')
        if 'source_label_name' in data.columns and str(r.source_label_name).strip()!=val:
            issues.append('SOURCE_LABEL_NAME_MISMATCH')
        if 'canonical_dataset_commit_sha' in data.columns and str(r.canonical_dataset_commit_sha).strip()!=COMMIT:
            issues.append('WRONG_PINNED_DATASET_COMMIT')
        records.append({'row_number':int(i)+2,'source_item_id':sid,'source_prompt_id':str(r.source_prompt_id),
                        'gold_label':int(r.gold_label),'label_name':str(r.label_name),
                        'expected_label_name':val or '', 'status':'PASS' if not issues else 'FAIL',
                        'issues':';'.join(issues)})
    out=pd.DataFrame(records)
    groups=data.groupby('source_prompt_id',sort=False)
    issues=[]
    if len(groups)!=240:issues.append(f'EXPECTED_240_PROMPTS_GOT_{len(groups)}')
    if not groups.size().eq(3).all():issues.append('NOT_THREE_ITEMS_PER_PROMPT')
    if not groups.gold_label.apply(lambda x:sorted(x.tolist())==[0,1,2]).all():
        issues.append('NOT_ONE_EACH_OF_THREE_LABELS_PER_PROMPT')
    if 'English Sentence' in data:
        if not groups['English Sentence'].apply(lambda x:len(set(x))==3).all():issues.append('DUPLICATE_ENGLISH_OPTIONS')
    if not (groups.bias_type.nunique()==1).all():issues.append('CATEGORY_INCONSISTENT_WITHIN_PROMPT')
    categories=data.groupby('bias_type').source_prompt_id.nunique().to_dict()
    if categories!={'gender':60,'profession':60,'race':60,'religion':60}:
        issues.append('CATEGORY_DISTRIBUTION_NOT_60_EACH:'+str(categories))
    if 'source_config' in data.columns and not data.source_config.astype(str).eq('intrasentence').all():
        issues.append('SOURCE_CONFIG_NOT_INTRASENTENCE')
    if 'Persian' in data.columns and not data['Persian'].astype(str).eq(data['Persian Sentence'].astype(str)).all():
        issues.append('PERSIAN_TEXT_ALIAS_MISMATCH')
    if 'full_sentence' in data.columns and not data['full_sentence'].astype(str).eq(data['English Sentence'].astype(str)).all():
        issues.append('ENGLISH_TEXT_ALIAS_MISMATCH')
    return out,issues


def main(argv=None):
    ap=argparse.ArgumentParser(description=__doc__)
    ap.add_argument('--input',required=True,help='v3.5 source-aligned CSV or Dataset_720 XLSX')
    ap.add_argument('--outdir',default='results/label_verification')
    ap.add_argument('--offline-snapshot',help='Use provided archived (previously verified) English snapshot instead of live HF; explicitly NOT live verification')
    args=ap.parse_args(argv)
    out=Path(args.outdir);out.mkdir(parents=True,exist_ok=True)
    data=read_data(args.input)
    mode='OFFLINE_ARCHIVED_SNAPSHOT_ONLY' if args.offline_snapshot else 'PINNED_HUGGINGFACE_ONLINE'
    try: ref=official_offline(args.offline_snapshot) if args.offline_snapshot else official_online()
    except Exception as e:
        print('FAIL: Cannot read official source. No successful verification claimed:',repr(e),file=sys.stderr)
        return 2
    rows,structural=audit(data,ref)
    rows.to_csv(out/'label_verification_per_row.csv',index=False,encoding='utf-8-sig')
    mismatches=int((rows.status=='FAIL').sum())
    result={'status':'PASS' if mismatches==0 and not structural else 'FAIL',
            'mode':mode,'dataset':DATASET,'config':'intrasentence','split':'validation',
            'pinned_commit_sha':COMMIT,'input_rows':len(data),'prompts':data.source_prompt_id.nunique(),
            'source_ids_matched':int(rows.issues.str.contains('SOURCE_ITEM_ID_NOT_FOUND').eq(False).sum()),
            'label_counts':{LABELS[k]:int(v) for k,v in data.gold_label.value_counts().items()},
            'numeric_text_source_mismatches':mismatches,'structural_issues':structural,
            'legacy_label_name_is_ignored':True,
            'legacy_label_mismatches_informational':int((data['legacy_label_name'].astype(str)!=data['label_name'].astype(str)).sum()) if 'legacy_label_name' in data else None,
            'human_cultural_validation_not_implied':True}
    (out/'label_verification_summary.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(result,ensure_ascii=False,indent=2))
    return 0 if result['status']=='PASS' else 1

if __name__=='__main__':sys.exit(main())
