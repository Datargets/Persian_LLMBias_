"""Figures replacing unsupported original claims. Figure 10/12/13 consistent PPL definition.
All figure captions/labels clearly differentiate cross-model BPP from within-model PPL.
"""
from pathlib import Path
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.stats import pearsonr
from bias_core import clean_dataset, token_summary

COLORS={'LLaMA':'#35698d','PersianLLaMA':'#bc7141'}


def generate_figures(dataset,scores,pairs,output_dir):
    dest=Path(output_dir);dest.mkdir(parents=True,exist_ok=True)
    d=clean_dataset(dataset)
    plt.rcParams.update({'font.size':10,'figure.dpi':140,'savefig.dpi':600})
    def save(n,stem):
        plt.tight_layout(); f=dest/f'fig_{n:02d}_{stem}.png'; plt.savefig(f,dpi=600,bbox_inches='tight'); plt.savefig(f.with_suffix('.pdf'),bbox_inches='tight'); plt.close(); return str(f)
    files=[]
    # 1. Original sentence lengths, only descriptive.
    fig,axs=plt.subplots(1,2,figsize=(12,4))
    for lang,col in [('English','English Sentence'),('Persian','Persian Sentence')]:
        chars=d[col].astype(str).str.len();words=d[col].astype(str).str.split().str.len()
        axs[0].hist(chars,bins=32,alpha=.45,density=True,label=lang)
        axs[1].hist(words,bins=20,alpha=.45,density=True,label=lang)
    axs[0].set(xlabel='Unicode characters per sentence',ylabel='Density',title='Sentence length in characters')
    axs[1].set(xlabel='Whitespace-delimited words per sentence',ylabel='Density',title='Approximate sentence length in words')
    for ax in axs:ax.legend()
    files.append(save(1,'sentence_length'))
    # 2: token counts per model/language
    fig,axs=plt.subplots(1,2,figsize=(12,4),sharex=False)
    for ax,lang in zip(axs,['English','Persian']):
        for m,c in COLORS.items():
            v=scores[(scores.language==lang)&(scores.model==m)].n_content_tokens
            ax.hist(v,bins=28,alpha=.45,density=True,label=m,color=c)
        ax.set(xlabel='Content tokens / sentence',ylabel='Density',title=lang);ax.legend()
    files.append(save(2,'token_count'))
    # 3: corpus CPT and byte per token
    t=token_summary(scores)
    fig,axs=plt.subplots(1,2,figsize=(12,4))
    for ax,metric,unit in [(axs[0],'corpus_cpt','Characters / token'),(axs[1],'corpus_bytes_per_token','UTF-8 bytes / token')]:
        wide=t.pivot(index='language',columns='model',values=metric).reindex(['English','Persian'])
        wide.plot(kind='bar',ax=ax,color=[COLORS[m] for m in wide.columns],rot=0)
        ax.set(ylabel=unit,xlabel='',title='Corpus-weighted '+unit)
        ax.legend(title='Model')
    files.append(save(3,'tokenization'))
    # 4 BPP distribution (comparable cross-model on same exact text)
    fig,axs=plt.subplots(1,2,figsize=(12,4))
    for ax,lang in zip(axs,['English','Persian']):
        for model,color in COLORS.items():
            v=scores[(scores.language==lang)&(scores.model==model)].bpb
            ax.hist(v,bins=35,density=True,alpha=.45,label=model,color=color)
        ax.set(xlabel='Bits / UTF-8 byte (lower = higher likelihood)',ylabel='Density',title=lang)
        ax.legend()
    files.append(save(4,'bits_per_byte'))
    # 5 paired BPP scatter
    fig,axs=plt.subplots(1,2,figsize=(12,4))
    pivot=scores.pivot(index=['item_id','language'],columns='model',values='bpb')
    for ax,lang in zip(axs,['English','Persian']):
        y=pivot.xs(lang,level='language').dropna()
        ax.scatter(y.LLaMA,y.PersianLLaMA,s=8,alpha=.38)
        mn=min(y.min().min(),y.max().max());mx=max(y.max().max(),y.min().min())
        ax.plot([mn,mx],[mn,mx],linestyle='--',color='gray',linewidth=.9)
        ax.set(xlabel='LLaMA BPP',ylabel='PersianLLaMA BPP',title=lang)
    files.append(save(5,'model_agreement_bpp'))
    # 6 directional signed gaps positive stereotype pref
    fig,axs=plt.subplots(1,2,figsize=(12,4),sharey=True)
    for ax,lang in zip(axs,['English','Persian']):
        for name,c in COLORS.items():
            a=pairs[(pairs.language==lang)&(pairs.model==name)]
            ax.hist(a.gap_bpb,bins=25,density=True,alpha=.4,color=c,label=name)
        ax.axvline(0,color='black',linestyle='--',linewidth=.8)
        ax.set(xlabel='BPP(anti) − BPP(stereo); positive = stereotype preferred',ylabel='Density',title=lang);ax.legend()
    files.append(save(6,'signed_bias_gaps'))
    # 7 CB is DISPERSION, not directional fairness
    plot=pairs.groupby(['bias_type','language','model']).triplet_dispersion_bpb.mean().reset_index()
    fig,axs=plt.subplots(1,2,figsize=(12,4),sharey=True)
    for ax,lang in zip(axs,['English','Persian']):
        p=plot[plot.language==lang].pivot(index='bias_type',columns='model',values='triplet_dispersion_bpb')
        p.plot(kind='bar',ax=ax,color=[COLORS[m] for m in p.columns],rot=20)
        ax.set(xlabel='',ylabel='Mean within-triplet variance (BPP²)',title=f'{lang}: dispersion, NOT directional bias')
        ax.legend(title='Model')
    files.append(save(7,'triplet_dispersion'))
    # 8/9 comparable likelihood per label, not raw PLL
    for ix,lang in [(8,'English'),(9,'Persian')]:
        p=scores[scores.language==lang].groupby(['bias_type','label_name','model']).bpb.mean().reset_index()
        labels=sorted(p.bias_type.unique()); fig,axs=plt.subplots(2,2,figsize=(12,7),sharey=True)
        for ax,cat in zip(axs.ravel(),labels):
            k=p[p.bias_type==cat].pivot(index='label_name',columns='model',values='bpb').reindex(['stereotype','anti-stereotype','unrelated'])
            k.plot(kind='bar',ax=ax,color=[COLORS[m] for m in k.columns],rot=15)
            ax.set(xlabel='',ylabel='Mean bits / byte',title=cat)
            ax.legend(title='Model')
        fig.suptitle(f'{lang}: likelihood by completion type (lower BPP = better)',y=1.02)
        files.append(save(ix,'label_bpb_'+lang.lower()))
    # 10 diagnostic PPL consistently median on log scale
    fig,axs=plt.subplots(1,2,figsize=(12,4),sharey=True)
    for ax,lang in zip(axs,['English','Persian']):
        p=scores[scores.language==lang].groupby(['bias_type','model']).ppl_token.median().unstack()
        p.plot(kind='bar',ax=ax,rot=20,color=[COLORS[m] for m in p.columns])
        ax.set_yscale('log');ax.set(xlabel='',ylabel='Median PPL/token (log scale)',title=f'{lang} | tokenizer-specific; not cross-model comparable')
        ax.legend(title='Model')
    files.append(save(10,'ppl_diagnostic'))
    # 11 signed log PPL ratio (within-model only)
    fig,axs=plt.subplots(1,2,figsize=(12,4),sharey=True)
    for ax,lang in zip(axs,['English','Persian']):
        wide=pairs[pairs.language==lang].groupby(['bias_type','model']).log_ppl_ratio.median().unstack()
        wide.plot(kind='bar',ax=ax,rot=20,color=[COLORS[m] for m in wide.columns])
        ax.axhline(0,color='black',linewidth=.8);ax.set(xlabel='',ylabel='Median ln(PPL anti / PPL stereo)',title=f'{lang}: within-model only')
        ax.legend(title='Model')
    files.append(save(11,'signed_log_ppl_ratio'))
    # 12/13 same median PPL definition as Fig 10 with full by-label detail
    for ix,lang in [(12,'English'),(13,'Persian')]:
        p=scores[scores.language==lang].groupby(['bias_type','label_name','model']).ppl_token.median().reset_index()
        fig,axs=plt.subplots(2,2,figsize=(12,7),sharey=True)
        for ax,cat in zip(axs.ravel(),sorted(p.bias_type.unique())):
            wide=p[p.bias_type==cat].pivot(index='label_name',columns='model',values='ppl_token').reindex(['stereotype','anti-stereotype','unrelated'])
            wide.plot(kind='bar',ax=ax,color=[COLORS[m] for m in wide.columns],rot=15)
            ax.set_yscale('log');ax.set(xlabel='',ylabel='Median token PPL, log scale',title=cat)
            ax.legend(title='Model')
        fig.suptitle(f'{lang}: diagnostic within-model PPL (NOT a cross-model fairness measure)',y=1.02)
        files.append(save(ix,'label_ppl_'+lang.lower()))
    # 14 cross-language paired preference and bpb correlation
    fig,axs=plt.subplots(1,2,figsize=(12,4))
    for ax,metric in zip(axs,['gap_bpb','log_ppl_ratio']):
        for model,c in COLORS.items():
            s=pairs[pairs.model==model].pivot(index='prompt_id',columns='language',values=metric).dropna()
            r,p=pearsonr(s.English,s.Persian)
            ax.scatter(s.English,s.Persian,s=9,alpha=.5,label=f'{model} r={r:.2f}',color=c)
        ax.axhline(0,color='gray',linewidth=.6);ax.axvline(0,color='gray',linewidth=.6)
        ax.set(xlabel='English',ylabel='Persian',title='Cross-language '+metric);ax.legend()
    files.append(save(14,'cross_language_correlations'))
    (dest/'figure_manifest.csv').write_text('figure,png_path,pdf_path\n'+'\n'.join(f'{i},{f},{str(Path(f).with_suffix(".pdf"))}' for i,f in enumerate(files,1)),encoding='utf8')
    return files
